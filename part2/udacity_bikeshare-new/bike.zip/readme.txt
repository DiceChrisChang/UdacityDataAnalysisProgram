参考
1，https://segmentfault.com/a/1190000012394176
2. https://blog.csdn.net/chinacmt/article/details/52192891
3. https://stackoverflow.com/questions/2083987/how-to-retry-after-exception-in-python
4. http://www.runoob.com/python/python-exceptions.html
5. https://stackoverflow.com/questions/32363098/pandas-dataframe-groupby-multiple-columns-then-sum
6. https://stackoverflow.com/questions/17679089/pandas-dataframe-groupby-two-columns-and-get-counts
7. https://stackoverflow.com/questions/17995024/how-to-assign-a-name-to-the-a-size-column
8. http://pandas.pydata.org/pandas-docs/version/0.19.2/generated/pandas.DataFrame.sort_values.html#pandas.DataFrame.sort_values
9. http://www.itkeyword.com/doc/9836292375735051067/how-to-compare-pandas-dataframe-against-none-in-python
10. https://stackoverflow.com/questions/23086383/how-to-test-nonetype-in-python
11. https://stackoverflow.com/questions/9752958/how-can-i-return-two-values-from-a-function-in-python
12. https://blog.csdn.net/joeblackzqq/article/details/35278665
